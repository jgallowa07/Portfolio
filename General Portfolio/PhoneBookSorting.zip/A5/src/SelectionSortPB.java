import java.util.ArrayList;

public class SelectionSortPB {

	//SOURCE CITED *MODIFIED*
//http://mathbits.com/MathBits/Java/arrays/SelectionSort.htm
	
	public static ArrayList<PhoneBookEntry> SelectionSort(ArrayList<PhoneBookEntry> Array){
		
		ArrayList<PhoneBookEntry> copyarray = new ArrayList<>(Array);

	    int i; 
	    int j; 
	    int first;
	    
	    PhoneBookEntry temp; 
	    for ( i = copyarray.size() - 1; i > 0; i-- ) 
	    {
	    	first = 0;   //initialize to subscript of first element
	        for(j = 1; j <= i; j++)   //locate smallest element between positions 1 and i.
	        {
	        	if(copyarray.get(j).GetName().compareToIgnoreCase(copyarray.get(first).GetName())>=0){        
	        		first = j;
	        }
	        temp = copyarray.get(first);   //swap smallest found with element in position i.
	        copyarray.set(first,copyarray.get(i));
	        copyarray.set(i,temp);
	         
	        }     
		
	    }
	    return copyarray;
	}
}
