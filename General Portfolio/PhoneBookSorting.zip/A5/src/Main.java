//this Program reads through an online text file with 50000 
//entries of phone numbers and their associated names
//It then displays a GUI which gives you the option of Sorting 
//the names either by Merge sort Algorithm or Selection Sort
//Merge sort is of O(log(n)) where Selection is O(n) So this 
//program displays just how long the different algorithms take to run in seconds

import javax.swing.JFrame;

public class Main {
	public static void main(String[] args) throws Exception {	
		MainFrame frame = new MainFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}
}
