
public class PhoneBookEntry {
	private final String _Name;
	private final String _Number;
	public PhoneBookEntry(String Name, String Number) {
		_Name = Name;
		_Number = Number;	
	}
	public String GetName(){
		return _Name;
	}
	public String GetNumber(){
		return _Number;
	}
}
