import java.util.ArrayList;

public class MergeSortPB {
	
	public static ArrayList<PhoneBookEntry> MergeSort(ArrayList<PhoneBookEntry> Array){
		
		if(Array.size() <=1){
			return Array;
		}
		int length = Array.size();
		int left_length = length/2;
		int right_length = length - left_length;
		
		
		ArrayList<PhoneBookEntry> left = new ArrayList<>(left_length);
		ArrayList<PhoneBookEntry> right = new ArrayList<>(right_length);
		for(int i = 0; i<left_length; i++){
			left.add(Array.get(i));
		}
		for(int i = left_length; i < length; i++){
			right.add(Array.get(i));
		}
		
		left = MergeSort(left);
		right = MergeSort(right);
		return Merge(left,right);

	}
	
	public static ArrayList<PhoneBookEntry> Merge(ArrayList<PhoneBookEntry> left, ArrayList<PhoneBookEntry> right){
		
		ArrayList<PhoneBookEntry> result = new ArrayList<>(left.size() + right.size());
		
		while((left.size() != 0) && (right.size() != 0)){
			if((left.get(0).GetName().compareToIgnoreCase(right.get(0).GetName()))<=0){
				result.add(left.get(0));
				left.remove(0);
			}else{
				result.add(right.get(0));
				right.remove(0);
			}	
		}

		result.addAll(left);
		result.addAll(right);
		return result;
	}
	

	
}