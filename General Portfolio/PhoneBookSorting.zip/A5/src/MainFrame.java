import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MainFrame extends JFrame implements ActionListener{
	private final JButton _button1;
	private final JButton _button2;
	private final JLabel _label;
	
	private static ArrayList<PhoneBookEntry> NewMergeArray;
	private static ArrayList<PhoneBookEntry> NewSelectionArray;
	
	private static ArrayList<PhoneBookEntry> BookEntryArray = new ArrayList<>();
	
	public MainFrame() throws Exception{
		
		super("Alphabatizing PhoneBook Entrys");
		setLayout(new BorderLayout());

	    URL oracle = new URL("https://www.cs.uoregon.edu/Classes/16F/cis212/assignments/phonebook.txt");
	    BufferedReader in = new BufferedReader(
	    new InputStreamReader(oracle.openStream()));
		
	    String inputLine;
	    //This loop runs through the file and add book objects to my arraylist giving constructor 
	    //the name and phone number at each line
	    while ((inputLine = in.readLine()) != null){  
	    	
	    	String PN = inputLine.substring(0,9);
	    	String Name = inputLine.substring(10);
	    	BookEntryArray.add(new PhoneBookEntry(Name,PN));
	  
	    }
	    in.close();
		//Makes a button for merge that adds an actionlistener and a new thread each time that
	    //actionlistener get fired
		_button1 = new JButton("Merge Sort");
		_button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Thread(new Runnable(){    //EXTRA CREDIT
					@Override
					public void run() {
						long startTimeNs = System.nanoTime();
						NewMergeArray = MergeSortPB.MergeSort(BookEntryArray);
						double elapsedTimeMs = elapsedTimeMs(startTimeNs);
						if(IsSorted(NewMergeArray)){
							_label.setText("MERGE TIME (Seconds)" + elapsedTimeMs/1000);
						}else{
							_label.setText("error");
						}	
					}
				}).start();
			}			
		});

		
		_button2 = new JButton("Selection Sort");
		_button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Thread(new Runnable(){   //EXTRA CREDIT
					@Override
					public void run() {
						long startTimeNs = System.nanoTime();
						NewSelectionArray = SelectionSortPB.SelectionSort(BookEntryArray);
						double elapsedTimeMs = elapsedTimeMs(startTimeNs);
						if(IsSorted(NewSelectionArray)){
							_label.setText("SELECTION TIME (Seconds)" + elapsedTimeMs/1000);
						}else{
							_label.setText("error");
						}	
					}					
				}).start();
			}			
		});

		//build grid layout
		JPanel bottomButtonPanel = new JPanel(new GridLayout(1,4));
		bottomButtonPanel.add(_button1);
		bottomButtonPanel.add(_button2);
		add(bottomButtonPanel,BorderLayout.CENTER);
		
		_label = new JLabel("                NO button clicked!            ");
		add(_label,BorderLayout.NORTH);
	}
	
	private static double elapsedTimeMs(long startTimeNs) {
		return (System.nanoTime() - startTimeNs)/1000000.0;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
	
	public static boolean IsSorted(ArrayList<PhoneBookEntry> arraylist){
		
		for(int i=0; i < arraylist.size()-1; i++){
			double compare = arraylist.get(i).GetName().compareToIgnoreCase(arraylist.get(i+1).GetName());
			if(compare<=0){
				continue;
			}else{
				return false;
			}
		}
		return true;
	}

}
