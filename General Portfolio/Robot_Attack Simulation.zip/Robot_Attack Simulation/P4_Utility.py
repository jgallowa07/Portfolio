class BadLineError(Exception):

    pass

class BadMsgError(Exception):

    pass
